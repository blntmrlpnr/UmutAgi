from deepface import DeepFace
import cv2
import matplotlib.pyplot as plt
import os
import numpy as np
from concurrent.futures import ThreadPoolExecutor, as_completed

def embedding_olustur(img_yolu):
    """
    Tek bir fotoğrafın embedding'ini çıkarır (hızlı işlem)
    """
    try:
        embedding = DeepFace.represent(
            img_path=img_yolu,
            model_name="ArcFace",
            detector_backend="retinaface",
            enforce_detection=False,
            align=True
        )
        return embedding[0]["embedding"]
    except Exception as e:
        print(f"⚠️ {img_yolu} embedding oluşturulamadı: {e}")
        return None

def cosine_distance(vec1, vec2):
    """
    İki vektör arasındaki cosine mesafesini hesaplar
    """
    vec1 = np.array(vec1)
    vec2 = np.array(vec2)
    return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))

def analiz_motoru(saha_fotosu, veritabani_yolu, baraj_orani=10.0, paralel=True):
    """
    Veritabanındaki tüm fotoğrafları tarar ve en yüksek benzerliğe göre sıralar.
    Optimized: Embedding'ler bir kez çıkarılır, sonra vektör karşılaştırması yapılır.
    """
    if not os.path.exists(saha_fotosu):
        print(f"❌ HATA: Saha fotoğrafı bulunamadı: {saha_fotosu}")
        return
    
    if not os.path.exists(veritabani_yolu):
        os.makedirs(veritabani_yolu)
        print(f"📁 '{veritabani_yolu}' klasörü oluşturuldu. Lütfen içine fotoğrafları atın.")
        return

    dosyalar = [f for f in os.listdir(veritabani_yolu) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
    
    if not dosyalar:
        print("❌ Veritabanı klasöründe taranacak fotoğraf bulunamadı!")
        return

    print(f"🔎 Toplam {len(dosyalar)} fotoğraf taranıyor. Lütfen bekleyin...")
    
    # ADIM 1: Ana fotoğrafın embedding'ini bir kez çıkar (30 saniye azalır)
    print("📷 Ana fotoğrafın özelliği analiz ediliyor...")
    saha_embedding = embedding_olustur(saha_fotosu)
    
    if saha_embedding is None:
        print("❌ Ana fotoğraf analiz edilemedi!")
        return
    
    sonuclar = []
    
    # ADIM 2: Tüm veritabanı fotoğraflarının embedding'lerini çıkar (paralel)
    print("🔄 Veritabanı fotoğrafları analiz ediliyor...")
    
    if paralel and len(dosyalar) > 1:
        # Paralel işlem (3+ fotoğraf için hızlı)
        with ThreadPoolExecutor(max_workers=4) as executor:
            futures = {}
            for dosya in dosyalar:
                tam_yol = os.path.join(veritabani_yolu, dosya)
                future = executor.submit(embedding_olustur, tam_yol)
                futures[future] = (dosya, tam_yol)
            
            completed = 0
            for future in as_completed(futures):
                completed += 1
                dosya, tam_yol = futures[future]
                embedding = future.result()
                
                if embedding is not None:
                    # ADIM 3: Embedding'ler arasındaki benzerliği hesapla
                    benzerlik_skoru = cosine_distance(saha_embedding, embedding) * 100
                    
                    if benzerlik_skoru >= baraj_orani:
                        sonuclar.append({
                            "dosya_adi": dosya,
                            "tam_yol": tam_yol,
                            "oran": benzerlik_skoru,
                        })
                
                print(f"   [{completed}/{len(dosyalar)}] {dosya}")
    else:
        # Seri işlem (1-2 fotoğraf için)
        for i, dosya in enumerate(dosyalar, 1):
            tam_yol = os.path.join(veritabani_yolu, dosya)
            embedding = embedding_olustur(tam_yol)
            
            if embedding is not None:
                benzerlik_skoru = cosine_distance(saha_embedding, embedding) * 100
                
                if benzerlik_skoru >= baraj_orani:
                    sonuclar.append({
                        "dosya_adi": dosya,
                        "tam_yol": tam_yol,
                        "oran": benzerlik_skoru,
                    })
            
            print(f"   [{i}/{len(dosyalar)}] {dosya}")


    # SONUÇLARI SIRALA (En yüksek benzerlik en üstte)
    sonuclar = sorted(sonuclar, key=lambda x: x['oran'], reverse=True)
    
    # GÖRSELLEŞTİRME DÖNGÜSÜ
    if not sonuclar:
        print(f"❌ %{baraj_orani} benzerlik barajını geçen kimse bulunamadı.")
    else:
        print(f"\n✅ {len(sonuclar)} olası aday bulundu. En yüksek ihtimalden başlanarak gösteriliyor...")
        print(f"💡 TIP: Fare Tekerleği (⬆️ ⬇️) ile Gezin | ESC ile Çıkış\n")
        
        # Resimleri ön yükle (tüm fotoğrafları memoryde tut)
        print("📦 Görseller yükleniyor...")
        img_cache = {}
        img_saha = cv2.imread(saha_fotosu)
        if img_saha is not None:
            img_saha = cv2.cvtColor(img_saha, cv2.COLOR_BGR2RGB)
        
        for aday in sonuclar:
            img = cv2.imread(aday['tam_yol'])
            if img is not None:
                img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            img_cache[aday['dosya_adi']] = img
        
        # İnteraktif gösterim
        current_index = [0]  # List kullanıyoruz çünkü fonksiyon içinde değer atanacak
        fig = None
        
        def guncelle_ekran():
            """Geçerli seçili fotoğrafı göster"""
            nonlocal fig
            
            if fig is not None:
                plt.close(fig)
            
            i = current_index[0]
            aday = sonuclar[i]
            
            # Durum metni belirleme
            if aday['oran'] >= 75:
                durum = "✅ YÜKSEK OLASILIK"
            elif aday['oran'] >= 50:
                durum = "⚠️ ORTA OLASILIK"
            else:
                durum = "❓ DÜŞÜK OLASILIK"

            print(f"[{i+1}/{len(sonuclar)}] {aday['dosya_adi']} - Benzerlik: %{aday['oran']:.2f}")

            fig = plt.figure(figsize=(13, 6))
            
            # Sol Panel: Saha Fotosu
            if img_saha is not None:
                plt.subplot(1, 2, 1)
                plt.imshow(img_saha)
                plt.title("Sahadan Gelen Görüntü", fontsize=12, fontweight='bold')
                plt.axis("off")

            # Sağ Panel: Veritabanındaki Aday
            img_aday = img_cache.get(aday['dosya_adi'])
            if img_aday is not None:
                plt.subplot(1, 2, 2)
                plt.imshow(img_aday)
                plt.title(f"Aday {i+1}: {aday['dosya_adi']}\nBenzerlik: %{aday['oran']:.2f}", 
                         fontsize=12, fontweight='bold')
                plt.axis("off")

            plt.suptitle(f"{durum} | Sıra: {i+1}/{len(sonuclar)} | Fare Tekerleği ile Gezin | ESC Çıkış", 
                        fontsize=12, fontweight='bold')
            plt.tight_layout()
            
            # Mouse scroll event handler
            def on_scroll(event):
                if event.button == 'up':  # Tekerlek yukarı
                    if current_index[0] > 0:
                        current_index[0] -= 1
                        guncelle_ekran()
                    else:
                        print("🏠 İlk aday. Daha yukarı gidemezsiniz.")
                
                elif event.button == 'down':  # Tekerlek aşağı
                    if current_index[0] < len(sonuclar) - 1:
                        current_index[0] += 1
                        guncelle_ekran()
                    else:
                        print("⏹️ Son aday. Daha aşağı gidemezsiniz.")
            
            # Keyboard event handler (ESC için)
            def on_key(event):
                if event.key == 'escape':  # ESC tuşu
                    print("👋 Gösterim kapatıldı.")
                    plt.close('all')
            
            fig.canvas.mpl_connect('scroll_event', on_scroll)
            fig.canvas.mpl_connect('key_press_event', on_key)
            plt.show(block=False)
            plt.pause(0.1)
        
        # İlk fotoğrafı göster
        guncelle_ekran()
        plt.show()

# --- AYARLAR VE ÇALIŞTIRMA ---
SAHA_FOTOSU = "saha_tespit.jpeg"  # Karşılaştırılacak ana foto
VERITABANI = "kayitli_veritabani" # Klasördeki tüm fotolarla kıyaslar

# Barajı %30-40 arası tutmak mantıklıdır (eski fotoğraflar için daha toleranslı)
# paralel=True: Hızlı işlem (önerilen), paralel=False: Bilgisayarın az güç harcaması
analiz_motoru(SAHA_FOTOSU, VERITABANI, baraj_orani=30.0, paralel=True)