import 'package:flutter_test/flutter_test.dart';
import 'package:afetagi/main.dart'; // package yerine direkt yolu verdik, hata biter

void main() {
  testWidgets('Umut Agi test', (WidgetTester tester) async {
    // Bizim sınıf adımız UmutAgiApp, widget_test'te HackathonApp kalmış olabilir
    await tester.pumpWidget(const UmutAgiApp());
  });
}
