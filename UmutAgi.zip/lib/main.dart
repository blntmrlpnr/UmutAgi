import 'dart:io';
import 'dart:typed_data';
import 'dart:async';
import 'package:flutter/services.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'dart:math';
import 'package:image_picker/image_picker.dart';

const MethodChannel voiceChannel = MethodChannel('com.umutagi.voice/intent');
final ValueNotifier<bool> globalVoiceSosTrigger = ValueNotifier(false);

void main() => runApp(const UmutAgiApp());

class UmutAgiApp extends StatelessWidget {
  const UmutAgiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Umut Ağı',
      themeMode: ThemeMode.dark,
      darkTheme: ThemeData.dark(useMaterial3: true).copyWith(
        colorScheme: ColorScheme.fromSeed(
            seedColor: Colors.red, brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xFF121212),
      ),
      home: const AnaIskelet(),
    );
  }
}

// --- VERİ MODELLERİ ---
class Rapor {
  String tur, aciklama;
  int oncelik;
  bool onayli;
  Color renk;
  LatLng konum;
  bool isSOS;
  Rapor(
      {required this.tur,
      required this.aciklama,
      required this.oncelik,
      this.onayli = false,
      required this.renk,
      required this.konum,
      this.isSOS = false});
}

class Ihtiyac {
  String tur, aciklama, tahminiVaris;
  Ihtiyac(
      {required this.tur, required this.aciklama, required this.tahminiVaris});
}

class Kayip {
  String adSoyad;
  String tcNo;
  String yas;
  Uint8List? foto;
  Kayip(
      {required this.adSoyad,
      required this.tcNo,
      required this.yas,
      this.foto});
}

class YardimEkibi {
  String isim;
  String tur;
  LatLng konum;
  IconData ikon;
  Color renk;
  YardimEkibi(
      {required this.isim,
      required this.tur,
      required this.konum,
      required this.ikon,
      required this.renk});
}

class YardimTiri {
  String plaka;
  String yukTuru;
  LatLng konum;
  YardimTiri({required this.plaka, required this.yukTuru, required this.konum});
}

// --- GLOBAL VERİLER ---
List<Rapor> tumRaporlar = [];
List<Ihtiyac> tumIhtiyaclar = [];
List<Kayip> tumKayiplar = [];
bool yetkiliGirisYapti = false;
List<YardimEkibi> yardimEkipleri = [];
List<YardimTiri> yardimTirlari = [];
bool _verilerOlusturuldu = false;

const LatLng kullaniciKonumu = LatLng(39.9208, 32.8541); // Ankara merkez
final List<Map<String, dynamic>> gercekToplanmaAlanlari = [
  {"isim": "Ömer Halisdemir Meydanı", "konum": const LatLng(37.9678, 34.6785)},
  {"isim": "Şehitler Parkı", "konum": const LatLng(37.9620, 34.6810)},
  {"isim": "Niğde Kültür Merkezi Önü", "konum": const LatLng(37.9710, 34.6730)},
];

// Türkiye ana karayolları
final List<List<LatLng>> turkiyeYollari = [
  // İstanbul - Ankara (O-4)
  [
    const LatLng(41.0082, 28.9784),
    const LatLng(40.7667, 29.9167),
    const LatLng(40.6500, 30.3950),
    const LatLng(40.1885, 32.6200),
    const LatLng(39.9208, 32.8541)
  ],
  // Ankara - Konya
  [
    const LatLng(39.9208, 32.8541),
    const LatLng(39.4000, 33.2000),
    const LatLng(38.7350, 32.4900),
    const LatLng(37.8746, 32.4932)
  ],
  // Ankara - Samsun
  [
    const LatLng(39.9208, 32.8541),
    const LatLng(40.2000, 33.8000),
    const LatLng(40.6000, 35.0000),
    const LatLng(41.2867, 36.3300)
  ],
  // İzmir - Ankara
  [
    const LatLng(38.4192, 27.1287),
    const LatLng(38.7400, 28.5000),
    const LatLng(38.9000, 30.0000),
    const LatLng(39.1000, 31.0000),
    const LatLng(39.9208, 32.8541)
  ],
  // Antalya - Konya
  [
    const LatLng(36.8969, 30.7133),
    const LatLng(37.2000, 31.0000),
    const LatLng(37.5000, 31.5000),
    const LatLng(37.8746, 32.4932)
  ],
  // Adana - Gaziantep
  [
    const LatLng(37.0000, 35.3213),
    const LatLng(37.0600, 36.2500),
    const LatLng(37.0594, 37.3825)
  ],
  // Trabzon - Erzurum
  [
    const LatLng(41.0027, 39.7168),
    const LatLng(40.6000, 40.3000),
    const LatLng(39.9042, 41.2679)
  ],
  // Diyarbakır - Van
  [
    const LatLng(37.9144, 40.2306),
    const LatLng(38.3000, 41.5000),
    const LatLng(38.5012, 43.3730)
  ],
  // İstanbul - İzmir
  [
    const LatLng(41.0082, 28.9784),
    const LatLng(40.3500, 28.2000),
    const LatLng(39.6000, 27.8000),
    const LatLng(38.4192, 27.1287)
  ],
  // Mersin - Adana
  [
    const LatLng(36.8000, 34.6330),
    const LatLng(36.9000, 35.0000),
    const LatLng(37.0000, 35.3213)
  ],
];

// Türkiye şehirleri ve afet risk bölgeleri
final List<Map<String, dynamic>> turkiyeSehirleri = [
  {
    'isim': 'İstanbul',
    'lat': 41.0082,
    'lng': 28.9784,
    'plaka': '34',
    'risk': 'Deprem',
    'kiyi': true
  },
  {
    'isim': 'Ankara',
    'lat': 39.9208,
    'lng': 32.8541,
    'plaka': '06',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'İzmir',
    'lat': 38.4192,
    'lng': 27.1287,
    'plaka': '35',
    'risk': 'Deprem',
    'kiyi': true
  },
  {
    'isim': 'Bursa',
    'lat': 40.1885,
    'lng': 29.0610,
    'plaka': '16',
    'risk': 'Deprem',
    'kiyi': true
  },
  {
    'isim': 'Antalya',
    'lat': 36.8969,
    'lng': 30.7133,
    'plaka': '07',
    'risk': 'Sel',
    'kiyi': true
  },
  {
    'isim': 'Adana',
    'lat': 37.0000,
    'lng': 35.3213,
    'plaka': '01',
    'risk': 'Sel',
    'kiyi': false
  },
  {
    'isim': 'Trabzon',
    'lat': 41.0027,
    'lng': 39.7168,
    'plaka': '61',
    'risk': 'Sel',
    'kiyi': true
  },
  {
    'isim': 'Gaziantep',
    'lat': 37.0594,
    'lng': 37.3825,
    'plaka': '27',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'Konya',
    'lat': 37.8746,
    'lng': 32.4932,
    'plaka': '42',
    'risk': 'Yangın',
    'kiyi': false
  },
  {
    'isim': 'Samsun',
    'lat': 41.2867,
    'lng': 36.3300,
    'plaka': '55',
    'risk': 'Sel',
    'kiyi': true
  },
  {
    'isim': 'Erzurum',
    'lat': 39.9042,
    'lng': 41.2679,
    'plaka': '25',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'Diyarbakır',
    'lat': 37.9144,
    'lng': 40.2306,
    'plaka': '21',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'Van',
    'lat': 38.5012,
    'lng': 43.3730,
    'plaka': '65',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'Hatay',
    'lat': 36.2023,
    'lng': 36.1613,
    'plaka': '31',
    'risk': 'Deprem',
    'kiyi': true
  },
  {
    'isim': 'Kahramanmaraş',
    'lat': 37.5753,
    'lng': 36.9228,
    'plaka': '46',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'Muğla',
    'lat': 37.2153,
    'lng': 28.3636,
    'plaka': '48',
    'risk': 'Yangın',
    'kiyi': true
  },
  {
    'isim': 'Artvin',
    'lat': 41.1828,
    'lng': 41.8183,
    'plaka': '08',
    'risk': 'Sel',
    'kiyi': true
  },
  {
    'isim': 'Rize',
    'lat': 41.0201,
    'lng': 40.5234,
    'plaka': '53',
    'risk': 'Sel',
    'kiyi': true
  },
  {
    'isim': 'Kastamonu',
    'lat': 41.3887,
    'lng': 33.7827,
    'plaka': '37',
    'risk': 'Sel',
    'kiyi': true
  },
  {
    'isim': 'Bolu',
    'lat': 40.7317,
    'lng': 31.6061,
    'plaka': '14',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'Malatya',
    'lat': 38.3554,
    'lng': 38.3335,
    'plaka': '44',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'Elazığ',
    'lat': 38.6810,
    'lng': 39.2264,
    'plaka': '23',
    'risk': 'Deprem',
    'kiyi': false
  },
  {
    'isim': 'Mersin',
    'lat': 36.8000,
    'lng': 34.6330,
    'plaka': '33',
    'risk': 'Sel',
    'kiyi': true
  },
  {
    'isim': 'Niğde',
    'lat': 37.9667,
    'lng': 34.6758,
    'plaka': '51',
    'risk': 'Deprem',
    'kiyi': false
  },
];

final _rng = Random();

final Map<String, Map<String, dynamic>> afetTipleri = {
  'Deprem': {'ikon': Icons.vibration, 'renk': Colors.redAccent, 'oncelik': 10},
  'Sel': {'ikon': Icons.water, 'renk': Colors.blueAccent, 'oncelik': 8},
  'Yangın': {
    'ikon': Icons.local_fire_department,
    'renk': Colors.deepOrange,
    'oncelik': 9
  },
  'Enkaz / Çökme': {
    'ikon': Icons.domain_disabled,
    'renk': Colors.red,
    'oncelik': 10
  },
  'Tıbbi Acil Durum': {
    'ikon': Icons.medical_services,
    'renk': Colors.pinkAccent,
    'oncelik': 7
  },
  'Heyelan': {'ikon': Icons.landscape, 'renk': Colors.brown, 'oncelik': 8},
};

IconData afetIkonu(String tur) {
  return (afetTipleri[tur]?['ikon'] as IconData?) ?? Icons.warning;
}

void _tumVerileriOlustur() {
  if (_verilerOlusturuldu) return;
  _verilerOlusturuldu = true;
  _yardimEkipleriniOlustur();
  _rastgeleAfetlerOlustur();
}

void _yardimEkipleriniOlustur() {
  if (yardimEkipleri.isNotEmpty) return;
  final ekipSablonlari = [
    {
      'isim': 'AKUT',
      'tur': 'Arama-Kurtarma',
      'ikon': Icons.search,
      'renk': Colors.orangeAccent
    },
    {
      'isim': 'Sağlık',
      'tur': 'Sağlık',
      'ikon': Icons.local_hospital,
      'renk': Colors.redAccent
    },
    {
      'isim': 'İtfaiye',
      'tur': 'İtfaiye',
      'ikon': Icons.fire_truck,
      'renk': Colors.deepOrange
    },
    {
      'isim': 'AFAD',
      'tur': 'Koordinasyon',
      'ikon': Icons.shield,
      'renk': Colors.blueAccent
    },
    {
      'isim': 'Jandarma',
      'tur': 'Güvenlik',
      'ikon': Icons.security,
      'renk': Colors.tealAccent
    },
    {
      'isim': 'Kızılay',
      'tur': 'İnsani Yardım',
      'ikon': Icons.volunteer_activism,
      'renk': Colors.red
    },
    {
      'isim': 'UMKE',
      'tur': 'Tıbbi Müdahale',
      'ikon': Icons.medical_services,
      'renk': Colors.pinkAccent
    },
    {
      'isim': 'Sahil Güvenlik',
      'tur': 'Deniz Kurtarma',
      'ikon': Icons.directions_boat,
      'renk': Colors.cyan
    },
  ];
  // Sahil Güvenlik hariç şablonlar
  final karaSablonlari =
      ekipSablonlari.where((e) => e['isim'] != 'Sahil Güvenlik').toList();
  final sahilSablon =
      ekipSablonlari.firstWhere((e) => e['isim'] == 'Sahil Güvenlik');
  for (var sehir in turkiyeSehirleri) {
    final ekipSayisi = 2 + _rng.nextInt(2);
    for (int i = 0; i < ekipSayisi; i++) {
      final sablon = karaSablonlari[_rng.nextInt(karaSablonlari.length)];
      yardimEkipleri.add(YardimEkibi(
        isim: '${sablon['isim']} - ${sehir['isim']}',
        tur: sablon['tur'] as String,
        konum: LatLng(
            (sehir['lat'] as double) + (_rng.nextDouble() - 0.5) * 0.08,
            (sehir['lng'] as double) + (_rng.nextDouble() - 0.5) * 0.08),
        ikon: sablon['ikon'] as IconData,
        renk: sablon['renk'] as Color,
      ));
    }
    // Sahil Güvenlik sadece kıyı şehirlerine (max 5)
    if (sehir['kiyi'] == true &&
        yardimEkipleri.where((e) => e.tur == 'Deniz Kurtarma').length < 5) {
      yardimEkipleri.add(YardimEkibi(
        isim: '${sahilSablon['isim']} - ${sehir['isim']}',
        tur: sahilSablon['tur'] as String,
        konum: LatLng(
            (sehir['lat'] as double) + (_rng.nextDouble() - 0.5) * 0.04,
            (sehir['lng'] as double) + (_rng.nextDouble() - 0.5) * 0.04),
        ikon: sahilSablon['ikon'] as IconData,
        renk: sahilSablon['renk'] as Color,
      ));
    }
  }
}

double _squaredDistance(LatLng a, LatLng b) {
  final dLat = a.latitude - b.latitude;
  final dLng = a.longitude - b.longitude;
  return dLat * dLat + dLng * dLng;
}

LatLng _projectPointOnSegment(LatLng a, LatLng b, LatLng p) {
  final dx = b.longitude - a.longitude;
  final dy = b.latitude - a.latitude;
  if (dx.abs() < 1e-9 && dy.abs() < 1e-9) return a;
  final t = ((p.longitude - a.longitude) * dx + (p.latitude - a.latitude) * dy) /
      (dx * dx + dy * dy);
  final tt = t.clamp(0.0, 1.0);
  return LatLng(a.latitude + dy * tt, a.longitude + dx * tt);
}

LatLng _yolUzerindeRastgeleNokta(LatLng yakinKonum) {
  double enYakinMesafe = double.infinity;
  LatLng? enYakinNokta;
  for (int y = 0; y < turkiyeYollari.length; y++) {
    for (int s = 0; s < turkiyeYollari[y].length - 1; s++) {
      final p1 = turkiyeYollari[y][s];
      final p2 = turkiyeYollari[y][s + 1];
      final proje = _projectPointOnSegment(p1, p2, yakinKonum);
      final mesafe = _squaredDistance(proje, yakinKonum);
      if (mesafe < enYakinMesafe) {
        enYakinMesafe = mesafe;
        enYakinNokta = proje;
      }
    }
  }
  if (enYakinNokta == null) return yakinKonum;
  return LatLng(
      enYakinNokta.latitude + (_rng.nextDouble() - 0.5) * 0.003,
      enYakinNokta.longitude + (_rng.nextDouble() - 0.5) * 0.003);
}

void _tirlariOlustur(LatLng ihbarKonumu) {
  final yukTurleri = [
    'Gıda',
    'Çadır',
    'İlaç',
    'Battaniye',
    'Su',
    'Jeneratör',
    'Giysi',
    'Hijyen Kiti'
  ];
  final plakaHarfler = ['A', 'B', 'C', 'D', 'E', 'F'];
  final tirSayisi = 2 + _rng.nextInt(3); // 2-4 tır per ihbar
  // En yakın şehrin plakasını bul
  String plaka = '06';
  double minDist = double.infinity;
  for (var s in turkiyeSehirleri) {
    final d = ((s['lat'] as double) - ihbarKonumu.latitude).abs() +
        ((s['lng'] as double) - ihbarKonumu.longitude).abs();
    if (d < minDist) {
      minDist = d;
      plaka = s['plaka'] as String;
    }
  }
  for (int i = 0; i < tirSayisi; i++) {
    yardimTirlari.add(YardimTiri(
      plaka:
          '$plaka ${plakaHarfler[_rng.nextInt(plakaHarfler.length)]}${plakaHarfler[_rng.nextInt(plakaHarfler.length)]} ${100 + _rng.nextInt(900)}',
      yukTuru: yukTurleri[_rng.nextInt(yukTurleri.length)],
      konum: _yolUzerindeRastgeleNokta(ihbarKonumu),
    ));
  }
}

void _rastgeleAfetlerOlustur() {
  if (tumRaporlar.isNotEmpty) return;
  final afetTurleriList = [
    'Deprem',
    'Sel',
    'Yangın',
    'Enkaz / Çökme',
    'Tıbbi Acil Durum',
    'Heyelan'
  ];
  final aciklamalar = {
    'Deprem': [
      'Şiddetli sarsıntı hissedildi',
      'Binalar hasar gördü, enkaz altında kalanlar var',
      '5.2 büyüklüğünde deprem',
      'Artçı sarsıntılar devam ediyor'
    ],
    'Sel': [
      'Yoğun yağış sonrası su baskını',
      'Dere taştı, evler su altında',
      'Araçlar selde sürüklendi',
      'Altyapı zarar gördü'
    ],
    'Yangın': [
      'Orman yangını kontrol altına alınamıyor',
      'Yerleşim yerine yakın yangın',
      'Fabrikada yangın çıktı',
      'Kuru ot yangını yayılıyor'
    ],
    'Enkaz / Çökme': [
      'Bina çöktü, kurtarma çalışması başladı',
      'İnşaat iskelesi çöktü',
      'Maden göçüğü meydana geldi'
    ],
    'Tıbbi Acil Durum': [
      'Toplu gıda zehirlenmesi',
      'Salgın hastalık riski',
      'Çok sayıda yaralı var'
    ],
    'Heyelan': [
      'Toprak kayması yolu kapattı',
      'Heyelan nedeniyle evler tehlikede',
      'Yol heyelan nedeniyle ulaşıma kapandı'
    ],
  };
  // Türkiye genelinde 15-20 rastgele afet oluştur
  final afetSayisi = 15 + _rng.nextInt(6);
  for (int i = 0; i < afetSayisi; i++) {
    final sehir = turkiyeSehirleri[_rng.nextInt(turkiyeSehirleri.length)];
    // Şehrin risk tipine ağırlıklı afet türü seç
    String afetTuru;
    if (_rng.nextDouble() < 0.6) {
      afetTuru = sehir['risk'] as String;
    } else {
      afetTuru = afetTurleriList[_rng.nextInt(afetTurleriList.length)];
    }
    final bilgi = afetTipleri[afetTuru]!;
    final aciklamaListesi = aciklamalar[afetTuru]!;
    final konum = LatLng(
        (sehir['lat'] as double) + (_rng.nextDouble() - 0.5) * 0.1,
        (sehir['lng'] as double) + (_rng.nextDouble() - 0.5) * 0.1);
    tumRaporlar.add(Rapor(
      tur: '$afetTuru - ${sehir['isim']}',
      aciklama: aciklamaListesi[_rng.nextInt(aciklamaListesi.length)],
      oncelik: bilgi['oncelik'] as int,
      renk: bilgi['renk'] as Color,
      konum: konum,
      onayli: _rng.nextDouble() < 0.5,
    ));
  }
}

// --- ANA İSKELET ---
class AnaIskelet extends StatefulWidget {
  const AnaIskelet({super.key});
  @override
  State<AnaIskelet> createState() => _AnaIskeletState();
}

class _AnaIskeletState extends State<AnaIskelet> {
  int _seciliSekme = 0;
  void _yenile() => setState(() {});

  @override
  void initState() {
    super.initState();
    voiceChannel.setMethodCallHandler((call) async {
      if (call.method == 'onVoiceCommand') {
        final query = call.arguments as String?;
        if (query != null && query.toLowerCase().contains("acil")) {
          setState(() => _seciliSekme = 0);
          globalVoiceSosTrigger.value = true;
        }
      }
    });
    voiceChannel.invokeMethod('getInitialQuery').then((query) {
      if (query is String && query.toLowerCase().contains("acil")) {
        setState(() => _seciliSekme = 0);
        globalVoiceSosTrigger.value = true;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> anaSayfalar = [
      SosEkrani(onGuncelle: _yenile),
      const KrizAkisiEkrani(),
      const ToplanmaAlaniEkrani(),
      yetkiliGirisYapti
          ? AdminPanelEkrani(onGuncelle: _yenile)
          : LoginEkrani(
              onLoginSuccess: () => setState(() {
                    yetkiliGirisYapti = true;
                    _seciliSekme = 3;
                  })),
    ];

    return Scaffold(
      extendBodyBehindAppBar: true,
      extendBody: true,
      appBar: AppBar(
        title: const Text('U M U T   A Ğ I',
            style: TextStyle(
                fontWeight: FontWeight.w800, fontSize: 18, letterSpacing: 2)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Colors.black.withOpacity(0.7), Colors.transparent]),
          ),
        ),
      ),
      drawer: Drawer(
        backgroundColor: const Color(0xFF1E1E1E),
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: BoxDecoration(color: Colors.red.shade900),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.shield, size: 50, color: Colors.white),
                  const SizedBox(height: 10),
                  const Text('Umut Ağı Modülleri',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 22,
                          fontWeight: FontWeight.bold)),
                  Text('Bağlantı: Mesh Ağ (Offline)',
                      style:
                          TextStyle(color: Colors.greenAccent, fontSize: 14)),
                ],
              ),
            ),
            ListTile(
              leading: const Icon(Icons.add_alert,
                  color: Colors.redAccent, size: 30),
              title: const Text('Durum & Afet Bildir',
                  style: TextStyle(fontSize: 16)),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => BildirEkrani(onGonder: _yenile)));
              },
            ),
            const Divider(color: Colors.white12),
            ListTile(
              leading: const Icon(Icons.inventory_2,
                  color: Colors.blueAccent, size: 30),
              title: const Text('İhtiyaç Talepleri',
                  style: TextStyle(fontSize: 16)),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => IhtiyacEkrani(onGonder: _yenile)));
              },
            ),
            const Divider(color: Colors.white12),
            ListTile(
              leading: const Icon(Icons.person_search,
                  color: Colors.orangeAccent, size: 30),
              title:
                  const Text('Kayıp İlanları', style: TextStyle(fontSize: 16)),
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => KayipEkrani(onGonder: _yenile)));
              },
            ),
          ],
        ),
      ),
      body: IndexedStack(index: _seciliSekme, children: anaSayfalar),
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF1A1A1A).withOpacity(0.85),
        indicatorColor: Colors.red.shade900.withOpacity(0.5),
        selectedIndex: _seciliSekme,
        onDestinationSelected: (index) => setState(() => _seciliSekme = index),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.sensors), label: 'S.O.S'),
          NavigationDestination(icon: Icon(Icons.list_alt), label: 'Akış'),
          NavigationDestination(icon: Icon(Icons.map), label: 'Harita'),
          NavigationDestination(
              icon: Icon(Icons.admin_panel_settings), label: 'Yetkili'),
        ],
      ),
    );
  }
}

class SosLongPressButton extends StatefulWidget {
  final VoidCallback onSosTriggered;
  const SosLongPressButton({super.key, required this.onSosTriggered});
  @override
  State<SosLongPressButton> createState() => _SosLongPressButtonState();
}

class _SosLongPressButtonState extends State<SosLongPressButton>
    with SingleTickerProviderStateMixin {
  bool _pressing = false;
  bool _triggered = false;
  double _progress = 0.0;
  Timer? _holdTimer;

  void _startHold() {
    if (_triggered) return;
    setState(() => _pressing = true);
    _holdTimer = Timer.periodic(const Duration(milliseconds: 50), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        _progress += 0.05 / 3.0; // 3 saniyede dolsun
        if (_progress >= 1.0) {
          _progress = 1.0;
          _triggered = true;
          _pressing = false;
          timer.cancel();
          widget.onSosTriggered();
          Future.delayed(const Duration(seconds: 4), () {
            if (mounted)
              setState(() {
                _triggered = false;
                _progress = 0.0;
              });
          });
        }
      });
    });
  }

  void _cancelHold() {
    _holdTimer?.cancel();
    if (!_triggered)
      setState(() {
        _pressing = false;
        _progress = 0.0;
      });
  }

  @override
  void dispose() {
    _holdTimer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onLongPressStart: (_) => _startHold(),
      onLongPressEnd: (_) => _cancelHold(),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 220,
        height: 220,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          color: _triggered
              ? Colors.green.shade800
              : (_pressing ? Colors.red.shade900 : Colors.red.shade700),
          boxShadow: [
            BoxShadow(
                color: (_pressing ? Colors.red : Colors.red.shade800)
                    .withOpacity(0.6),
                blurRadius: _pressing ? 30 : 15,
                spreadRadius: _pressing ? 8 : 3),
          ],
          border: Border.all(
              color: _triggered ? Colors.greenAccent : Colors.redAccent,
              width: 3),
        ),
        child: Stack(alignment: Alignment.center, children: [
          SizedBox(
              width: 200,
              height: 200,
              child: CircularProgressIndicator(
                value: _progress,
                strokeWidth: 6,
                backgroundColor: Colors.white.withOpacity(0.1),
                valueColor: AlwaysStoppedAnimation<Color>(
                    _triggered ? Colors.greenAccent : Colors.white),
              )),
          Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(_triggered ? Icons.check : Icons.sos,
                color: Colors.white, size: 48),
            const SizedBox(height: 6),
            Text(_triggered ? "İLETİLDİ" : "S.O.S",
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 24,
                    letterSpacing: 2)),
            if (!_triggered && !_pressing)
              const Text("Basılı Tut",
                  style: TextStyle(color: Colors.white60, fontSize: 12)),
            if (_pressing)
              Text("${(_progress * 100).toInt()}%",
                  style: const TextStyle(
                      color: Colors.white70,
                      fontSize: 11,
                      fontWeight: FontWeight.bold)),
          ]),
        ]),
      ),
    );
  }
}

// --- 1. S.O.S EKRANI ---
class SosEkrani extends StatefulWidget {
  final VoidCallback onGuncelle;
  const SosEkrani({super.key, required this.onGuncelle});
  @override
  State<SosEkrani> createState() => _SosEkraniState();
}

class _SosEkraniState extends State<SosEkrani> {
  final AudioPlayer _audioPlayer = AudioPlayer();
  List<String> seciliDurumlar = [];
  final List<String> oncelikDurumlari = [
    "🤰 Hamile / Bebekli",
    "🧓 Çocuk / Yaşlı",
    "♿ Engelli / Hasta",
    "🩸 Ağır Yaralı"
  ];
  bool _smsAktif = false;
  Timer? _smsTimer;
  int _sonrakiSmsSaniye = 10;
  int _smsGonderimSaniye = 0;
  bool _smsGonderiliyor = false;
  bool _sosGonderildi = false;
  int _toplamSmsGonderilen = 0;

  // Kişisel bilgiler
  late final String _isimSoyisim;
  late final String _kanGrubu;
  late final String _hastalik;
  late final String _alerji;
  final String _acilTel1 = '05367458292';
  final String _acilTel2 = '05059867728';

  @override
  void initState() {
    super.initState();
    globalVoiceSosTrigger.addListener(_voiceTriggerListener);
    if (globalVoiceSosTrigger.value) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _sosGonder());
      globalVoiceSosTrigger.value = false;
    }
    final rng = Random();
    final isimler = [
      'Ahmet Yılmaz',
      'Mehmet Demir',
      'Ayşe Kaya',
      'Fatma Çelik',
      'Ali Şahin',
      'Zeynep Arslan',
      'Mustafa Özkan',
      'Elif Aydın'
    ];
    final kanGruplari = [
      'A Rh+',
      'A Rh-',
      'B Rh+',
      'B Rh-',
      'AB Rh+',
      'AB Rh-',
      '0 Rh+',
      '0 Rh-'
    ];
    final hastaliklar = [
      'Diyabet',
      'Astım',
      'Hipertansiyon',
      'Epilepsi',
      'Kalp Yetmezliği',
      'Yok'
    ];
    final alerjiler = [
      'Penisilin',
      'Aspirin',
      'Fıstık',
      'Latex',
      'Arı Sokması',
      'Yok'
    ];
    _isimSoyisim = isimler[rng.nextInt(isimler.length)];
    _kanGrubu = kanGruplari[rng.nextInt(kanGruplari.length)];
    _hastalik = hastaliklar[rng.nextInt(hastaliklar.length)];
    _alerji = alerjiler[rng.nextInt(alerjiler.length)];
  }

  void _voiceTriggerListener() {
    if (globalVoiceSosTrigger.value && !_sosGonderildi) {
      _sosGonder();
      globalVoiceSosTrigger.value = false;
    }
  }

  void _sosGonder() {
    String ekBilgi = seciliDurumlar.isEmpty
        ? "KULLANICI ACİL YARDIM İSTİYOR!"
        : "ACİL DURUM! Öncelikli Gruplar: ${seciliDurumlar.join(', ')}";
    tumRaporlar.add(Rapor(
        tur: "SOS SİNYALİ",
        aciklama: ekBilgi,
        oncelik: 100,
        renk: Colors.redAccent,
        konum: kullaniciKonumu,
        isSOS: true));
    _tirlariOlustur(kullaniciKonumu);
    widget.onGuncelle();
    setState(() {
      seciliDurumlar.clear();
      _sosGonderildi = true;
    });
    // SMS gönderimini otomatik başlat
    _smsBaslat();
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext c) {
        return Dialog(
          backgroundColor: const Color(0xFF1E1E1E),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          insetPadding:
              const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
          child: Container(
            padding: const EdgeInsets.all(24),
            constraints:
                BoxConstraints(maxHeight: MediaQuery.of(c).size.height * 0.85),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Row(children: [
                Icon(Icons.warning_amber_rounded,
                    color: Colors.redAccent, size: 36),
                SizedBox(width: 12),
                Expanded(
                    child: Text("S.O.S İLETİLDİ!\nHAYATİ TALİMATLAR",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 18,
                            fontWeight: FontWeight.bold)))
              ]),
              const Divider(color: Colors.white24, height: 30),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                    color: Colors.green.shade900.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(10),
                    border:
                        Border.all(color: Colors.greenAccent.withOpacity(0.3))),
                child: Row(children: [
                  const Icon(Icons.sms, color: Colors.greenAccent, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                      child: Text(
                          "📲 SMS gönderildi: \"YARDIMA İHTİYACIM VAR\"\nAlıcılar: $_acilTel1, $_acilTel2",
                          style: const TextStyle(
                              color: Colors.greenAccent,
                              fontSize: 12,
                              fontWeight: FontWeight.w500))),
                ]),
              ),
              const SizedBox(height: 12),
              const Text("Ekipler gelene kadar talimatları uygulayın:",
                  style: TextStyle(
                      color: Colors.greenAccent, fontWeight: FontWeight.w600)),
              const SizedBox(height: 10),
              Expanded(
                  child: SingleChildScrollView(
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                    _rehberBaslik("1. Deprem Anında"),
                    _rehberMadde(
                        "Çök, Kapan, Tutun:", "Güvenli eşyanın yanına çökün."),
                    _rehberBaslik("2. Yangın Anında"),
                    _rehberMadde(
                        "Duman Altında Kalın:", "Yere yakın çıkışa ilerleyin."),
                    _rehberBaslik("3. Sel Anında"),
                    _rehberMadde("Yüksek Kesimlere Çıkın:",
                        "Hızla yüksek alanlara gidin."),
                  ]))),
              const SizedBox(height: 20),
              SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.green.shade700,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12))),
                    onPressed: () => Navigator.pop(c),
                    child: const Text("ANLADIM, GÜVENDEYİM",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 16)),
                  ))
            ]),
          ),
        );
      },
    );
  }

  void _smsBaslat() {
    setState(() {
      _smsAktif = true;
      _smsGonderiliyor = true;
      _smsGonderimSaniye = 5;
      _sonrakiSmsSaniye = 10;
      _toplamSmsGonderilen++;
    });
    _smsTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      setState(() {
        if (_smsGonderiliyor) {
          _audioPlayer.play(AssetSource('dog_whistle.wav'));
          _smsGonderimSaniye--;
          if (_smsGonderimSaniye <= 0) {
            _smsGonderiliyor = false;
            _sonrakiSmsSaniye = 10;
          }
        } else {
          _sonrakiSmsSaniye--;
          if (_sonrakiSmsSaniye <= 0) {
            _smsGonderiliyor = true;
            _smsGonderimSaniye = 5;
            _toplamSmsGonderilen++;
          }
        }
      });
    });
  }

  void _smsDurdur() {
    _smsTimer?.cancel();
    setState(() {
      _smsAktif = false;
      _smsGonderiliyor = false;
      _sonrakiSmsSaniye = 10;
      _smsGonderimSaniye = 0;
    });
  }

  @override
  void dispose() {
    globalVoiceSosTrigger.removeListener(_voiceTriggerListener);
    _smsTimer?.cancel();
    _audioPlayer.dispose();
    super.dispose();
  }

  Widget _rehberBaslik(String metin) => Padding(
      padding: const EdgeInsets.only(top: 20, bottom: 8),
      child: Text(metin,
          style: const TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.orangeAccent)));
  Widget _rehberMadde(String baslik, String icerik) => Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: RichText(
          text: TextSpan(
              style: const TextStyle(
                  fontSize: 14, color: Colors.white70, height: 1.5),
              children: [
            TextSpan(
                text: "• $baslik ",
                style: const TextStyle(
                    fontWeight: FontWeight.bold, color: Colors.redAccent)),
            TextSpan(text: icerik)
          ])));

  Widget _kisiselBilgiKarti() {
    return Align(
        alignment: Alignment.center,
        child: Container(
          width: 280,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 16),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.65),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Text(_isimSoyisim,
                textAlign: TextAlign.center,
                style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16)),
            const SizedBox(height: 6),
            Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                    color: Colors.red.shade900,
                    borderRadius: BorderRadius.circular(6)),
                child: Text(_kanGrubu,
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w900,
                        fontSize: 12))),
            const Divider(color: Colors.white10, height: 20),
            Row(children: [
              _miniInfo(Icons.medical_services, _hastalik, Colors.orangeAccent),
              const SizedBox(width: 12),
              _miniInfo(Icons.warning_amber, _alerji, Colors.amberAccent),
            ]),
            const Divider(color: Colors.white10, height: 16),
            Row(children: [
              const Icon(Icons.phone, color: Colors.greenAccent, size: 13),
              const SizedBox(width: 4),
              Text(_acilTel1,
                  style: const TextStyle(color: Colors.white70, fontSize: 11)),
              const SizedBox(width: 12),
              const Icon(Icons.phone, color: Colors.greenAccent, size: 13),
              const SizedBox(width: 4),
              Text(_acilTel2,
                  style: const TextStyle(color: Colors.white70, fontSize: 11)),
            ]),
          ]),
        ));
  }

  Widget _miniInfo(IconData ikon, String deger, Color renk) {
    return Expanded(
        child: Row(children: [
      Icon(ikon, color: renk, size: 13),
      const SizedBox(width: 4),
      Flexible(
          child: Text(deger,
              style: const TextStyle(color: Colors.white70, fontSize: 11),
              overflow: TextOverflow.ellipsis)),
    ]));
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: double.infinity,
      decoration: BoxDecoration(
          image: DecorationImage(
              image: const AssetImage('assets/arkaplan.png'),
              fit: BoxFit.cover,
              colorFilter: ColorFilter.mode(
                  Colors.black.withOpacity(0.55), BlendMode.darken))),
      child: SafeArea(
          child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const SizedBox(height: 8),
              Center(
                child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                    decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.5),
                        borderRadius: BorderRadius.circular(20)),
                    child: const Text("YARDIM ÇAĞRISI",
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w600,
                            color: Colors.white,
                            letterSpacing: 3))),
              ),
              const SizedBox(height: 16),
              // KİŞİSEL BİLGİ KARTI (sola yapışık)
              _kisiselBilgiKarti(),
              const SizedBox(height: 24),
              // SOS DÜĞME (ortada)
              Center(child: SosLongPressButton(onSosTriggered: _sosGonder)),
              const SizedBox(height: 20),
              // SMS SİSTEMİ
              if (_smsAktif) ...[
                Center(
                    child: Container(
                  width: 280,
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: _smsGonderiliyor
                        ? Colors.green.shade900.withOpacity(0.8)
                        : Colors.black.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                        color: _smsGonderiliyor
                            ? Colors.greenAccent
                            : Colors.white24,
                        width: 2),
                    boxShadow: _smsGonderiliyor
                        ? [
                            BoxShadow(
                                color: Colors.green.withOpacity(0.4),
                                blurRadius: 20,
                                spreadRadius: 3)
                          ]
                        : [],
                  ),
                  child: Column(children: [
                    Icon(_smsGonderiliyor ? Icons.sms : Icons.timer,
                        color: _smsGonderiliyor
                            ? Colors.greenAccent
                            : Colors.white54,
                        size: 40),
                    const SizedBox(height: 10),
                    Text(
                      _smsGonderiliyor
                          ? "📲 SMS GÖNDERİLİYOR"
                          : "⏳ Sonraki SMS bekleniyor",
                      style: TextStyle(
                          color: _smsGonderiliyor
                              ? Colors.greenAccent
                              : Colors.white54,
                          fontWeight: FontWeight.bold,
                          fontSize: 15),
                    ),
                    const SizedBox(height: 6),
                    if (_smsGonderiliyor)
                      const Text("\"YARDIMA İHTİYACIM VAR\"",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16)),
                    const SizedBox(height: 6),
                    Text(
                      _smsGonderiliyor
                          ? "$_smsGonderimSaniye sn"
                          : "$_sonrakiSmsSaniye sn",
                      style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w900,
                          fontSize: 42),
                    ),
                    Text(
                      _smsGonderiliyor
                          ? "SMS gönderim süresi"
                          : "Sonraki SMS'e kalan",
                      style:
                          const TextStyle(color: Colors.white38, fontSize: 11),
                    ),
                    const SizedBox(height: 8),
                    LinearProgressIndicator(
                      value: _smsGonderiliyor
                          ? _smsGonderimSaniye / 5.0
                          : 1.0 - (_sonrakiSmsSaniye / 10.0),
                      backgroundColor: Colors.white24,
                      valueColor: AlwaysStoppedAnimation<Color>(_smsGonderiliyor
                          ? Colors.greenAccent
                          : Colors.white30),
                      minHeight: 5,
                    ),
                    const SizedBox(height: 8),
                    Text("Toplam gönderilen SMS: $_toplamSmsGonderilen",
                        style: const TextStyle(
                            color: Colors.white38, fontSize: 11)),
                  ]),
                )),
                const SizedBox(height: 12),
                SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      icon: const Icon(Icons.stop, color: Colors.white),
                      label: const Text("SMS'İ DURDUR",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.grey.shade800,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12))),
                      onPressed: _smsDurdur,
                    )),
              ],
              const SizedBox(height: 16),
              Theme(
                  data: Theme.of(context)
                      .copyWith(dividerColor: Colors.transparent),
                  child: Card(
                    color: Colors.black.withOpacity(0.7),
                    elevation: 8,
                    shadowColor: Colors.black,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                        side: BorderSide(color: Colors.white.withOpacity(0.1))),
                    child: ExpansionTile(
                      iconColor: Colors.redAccent,
                      collapsedIconColor: Colors.white,
                      leading: const Icon(Icons.health_and_safety,
                          color: Colors.redAccent),
                      title: const Text("Öncelikli Durum Bildir",
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.w600,
                              fontSize: 15)),
                      subtitle: Text(
                          seciliDurumlar.isEmpty
                              ? "İsteğe bağlı ek bilgi ekleyin"
                              : "${seciliDurumlar.length} durum seçildi",
                          style: TextStyle(
                              color: seciliDurumlar.isEmpty
                                  ? Colors.white70
                                  : Colors.greenAccent,
                              fontSize: 12)),
                      childrenPadding: const EdgeInsets.only(
                          left: 16, right: 16, bottom: 20),
                      children: [
                        Wrap(
                            spacing: 8,
                            runSpacing: 8,
                            alignment: WrapAlignment.center,
                            children: oncelikDurumlari.map((durum) {
                              final bool secili =
                                  seciliDurumlar.contains(durum);
                              return FilterChip(
                                label: Text(durum,
                                    style: TextStyle(
                                        fontSize: 12,
                                        color: Colors.white,
                                        fontWeight: secili
                                            ? FontWeight.bold
                                            : FontWeight.normal)),
                                selected: secili,
                                showCheckmark: false,
                                selectedColor: Colors.red.shade800,
                                backgroundColor: Colors.black.withOpacity(0.5),
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(8),
                                    side: BorderSide(
                                        color: secili
                                            ? Colors.redAccent
                                            : Colors.transparent)),
                                onSelected: (bool value) {
                                  setState(() {
                                    if (value)
                                      seciliDurumlar.add(durum);
                                    else
                                      seciliDurumlar.remove(durum);
                                  });
                                },
                              );
                            }).toList())
                      ],
                    ),
                  )),
            ]),
      )),
    );
  }
}

// --- 2. KRİZ AKIŞI EKRANI ---
class KrizAkisiEkrani extends StatelessWidget {
  const KrizAkisiEkrani({super.key});

  @override
  Widget build(BuildContext context) {
    _tumVerileriOlustur();
    final raporlar = tumRaporlar.toList()
      ..sort((a, b) => b.oncelik.compareTo(a.oncelik));
    return Scaffold(
      appBar: AppBar(
          title: const Text("Canlı Afet Akışı", style: TextStyle(fontSize: 16)),
          automaticallyImplyLeading: false,
          backgroundColor: Colors.transparent,
          elevation: 0),
      body: raporlar.isEmpty
          ? const Center(
              child: Text("Şu an sistemde bildirim bulunmuyor.",
                  style: TextStyle(color: Colors.white38)))
          : ListView.builder(
              itemCount: raporlar.length,
              itemBuilder: (context, index) {
                final r = raporlar[index];
                final afetAdi = r.tur.split(' - ').first;
                return Card(
                  margin:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12)),
                  color: r.isSOS
                      ? Colors.red.withOpacity(0.15)
                      : const Color(0xFF1E1E1E),
                  child: ListTile(
                    leading: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                          color: r.renk.withOpacity(0.2),
                          shape: BoxShape.circle),
                      child: Icon(afetIkonu(afetAdi), color: r.renk, size: 28),
                    ),
                    title: Text(r.tur,
                        style: const TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 14)),
                    subtitle: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(r.aciklama,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 12)),
                          const SizedBox(height: 4),
                          Row(children: [
                            Icon(r.onayli ? Icons.verified : Icons.pending,
                                size: 14,
                                color: r.onayli
                                    ? Colors.greenAccent
                                    : Colors.amber),
                            const SizedBox(width: 4),
                            Text(r.onayli ? 'Doğrulandı' : 'Onay Bekliyor',
                                style: TextStyle(
                                    fontSize: 11,
                                    color: r.onayli
                                        ? Colors.greenAccent
                                        : Colors.amber)),
                          ]),
                        ]),
                    trailing: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 4),
                      decoration: BoxDecoration(
                          color: r.renk.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(8)),
                      child: Text('Öncelik: ${r.oncelik}',
                          style: TextStyle(
                              color: r.renk,
                              fontSize: 11,
                              fontWeight: FontWeight.bold)),
                    ),
                  ),
                );
              },
            ),
    );
  }
}

// --- 3. HARİTA EKRANI ---
class ToplanmaAlaniEkrani extends StatelessWidget {
  const ToplanmaAlaniEkrani({super.key});

  @override
  Widget build(BuildContext context) {
    _tumVerileriOlustur();
    return Stack(
      children: [
        FlutterMap(
          options: MapOptions(initialCenter: kullaniciKonumu, initialZoom: 6.0),
          children: [
            TileLayer(
                urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                userAgentPackageName: 'com.hackathon.umutagi'),
            MarkerLayer(
              markers: [
                Marker(
                    point: kullaniciKonumu,
                    width: 80,
                    height: 80,
                    child: const Column(children: [
                      Icon(Icons.my_location,
                          color: Colors.blueAccent, size: 40),
                      Text("Buradasınız",
                          style: TextStyle(
                              fontSize: 10,
                              fontWeight: FontWeight.bold,
                              backgroundColor: Colors.white,
                              color: Colors.black))
                    ])),
                ...gercekToplanmaAlanlari.map((alan) => Marker(
                      point: alan["konum"],
                      width: 120,
                      height: 80,
                      child: Column(children: [
                        const Icon(Icons.shield, color: Colors.green, size: 40),
                        Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                                color: Colors.green.shade900,
                                borderRadius: BorderRadius.circular(4)),
                            child: Text(alan["isim"],
                                textAlign: TextAlign.center,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 9,
                                    fontWeight: FontWeight.bold))),
                      ]),
                    )),
                // Afet İhbarları (simgeleriyle)
                ...tumRaporlar.map((r) => Marker(
                      point: r.konum,
                      width: 80,
                      height: 80,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                                color: r.renk.withOpacity(0.85),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                      color: r.renk.withOpacity(0.6),
                                      blurRadius: 10,
                                      spreadRadius: 3)
                                ]),
                            child: Icon(afetIkonu(r.tur.split(' - ').first),
                                color: Colors.white, size: 18)),
                        const SizedBox(height: 1),
                        Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 3, vertical: 1),
                            decoration: BoxDecoration(
                                color: Colors.black87,
                                borderRadius: BorderRadius.circular(3)),
                            child: Text(r.tur.split(' - ').last,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 7,
                                    fontWeight: FontWeight.bold))),
                      ]),
                    )),
                // Yardım Ekipleri
                ...yardimEkipleri.map((ekip) => Marker(
                      point: ekip.konum,
                      width: 120,
                      height: 80,
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Container(
                            padding: const EdgeInsets.all(6),
                            decoration: BoxDecoration(
                                color: ekip.renk.withOpacity(0.9),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                      color: ekip.renk.withOpacity(0.5),
                                      blurRadius: 8,
                                      spreadRadius: 2)
                                ]),
                            child:
                                Icon(ekip.ikon, color: Colors.white, size: 22)),
                        const SizedBox(height: 2),
                        Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 4, vertical: 2),
                            decoration: BoxDecoration(
                                color: Colors.black87,
                                borderRadius: BorderRadius.circular(4)),
                            child: Text(ekip.isim,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 8,
                                    fontWeight: FontWeight.bold))),
                      ]),
                    )),
              ],
            ),
          ],
        ),
        Positioned(
          top: 55, // Drawer ikonu ile aynı hizaya gelmesi için yukarı çekildi
          left:
              60, // Drawer ikonunun üzerine binmemesi için soldan boşluk bırakıldı
          right: 16,
          child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  color: Colors.black87,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: Colors.green.withOpacity(0.5))),
              child: const Row(children: [
                Icon(Icons.info_outline, color: Colors.greenAccent),
                SizedBox(width: 10),
                Expanded(
                    child: Text("Türkiye Afet Haritası & Yardım Ekipleri",
                        style: TextStyle(
                            color: Colors.white, fontWeight: FontWeight.w500)))
              ])),
        )
      ],
    );
  }
}

// --- 4. YETKİLİ PANELİ VE GİRİŞ ---
class AdminPanelEkrani extends StatefulWidget {
  final VoidCallback onGuncelle;
  const AdminPanelEkrani({super.key, required this.onGuncelle});
  @override
  State<AdminPanelEkrani> createState() => _AdminPanelEkraniState();
}

class _AdminPanelEkraniState extends State<AdminPanelEkrani> {
  bool haritaGorunumu = false;
  bool canliAkisAcik = false;
  @override
  Widget build(BuildContext context) {
    tumRaporlar.sort((a, b) => b.oncelik.compareTo(a.oncelik));
    return Column(
      children: [
        SizedBox(height: MediaQuery.of(context).padding.top + kToolbarHeight),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
              color: const Color(0xFF1E1E1E),
              border: Border(
                  bottom: BorderSide(color: Colors.white.withOpacity(0.1)))),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(children: [
                Icon(Icons.admin_panel_settings, color: Colors.greenAccent),
                SizedBox(width: 8),
                Text("Yetkili: Bülent",
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold))
              ]),
              Row(children: [
                if (haritaGorunumu)
                  IconButton(
                    icon: Icon(canliAkisAcik ? Icons.close : Icons.feed_rounded,
                        color: Colors.amber),
                    onPressed: () =>
                        setState(() => canliAkisAcik = !canliAkisAcik),
                    tooltip: 'Canlı Afet Akışı',
                  ),
                IconButton(
                    icon: Icon(
                        haritaGorunumu
                            ? Icons.format_list_bulleted
                            : Icons.map_rounded,
                        color: Colors.blueAccent),
                    onPressed: () => setState(() {
                          haritaGorunumu = !haritaGorunumu;
                          if (!haritaGorunumu) canliAkisAcik = false;
                        })),
                IconButton(
                    icon: const Icon(Icons.logout_rounded,
                        color: Colors.redAccent),
                    onPressed: () {
                      yetkiliGirisYapti = false;
                      widget.onGuncelle();
                    }),
              ])
            ],
          ),
        ),
        Expanded(child: haritaGorunumu ? _haritaVeDrawer() : _listeOlustur()),
      ],
    );
  }

  Widget _haritaVeDrawer() {
    return Stack(children: [
      _haritaOlustur(),
      // Sağ taraftan canlı afet akışı drawer'ı
      AnimatedPositioned(
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
        right: canliAkisAcik ? 0 : -320,
        top: 0,
        bottom: 0,
        child: Container(
          width: 320,
          decoration: BoxDecoration(
            color: const Color(0xFF1A1A1A).withOpacity(0.95),
            border: Border(
                left:
                    BorderSide(color: Colors.amber.withOpacity(0.3), width: 1)),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.5),
                  blurRadius: 20,
                  offset: const Offset(-5, 0))
            ],
          ),
          child: Column(children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: Colors.amber.shade900.withOpacity(0.3),
                  border: Border(
                      bottom:
                          BorderSide(color: Colors.amber.withOpacity(0.2)))),
              child: Row(children: [
                const Icon(Icons.feed_rounded, color: Colors.amber, size: 22),
                const SizedBox(width: 10),
                const Expanded(
                    child: Text('Canlı Afet Akışı',
                        style: TextStyle(
                            color: Colors.amber,
                            fontWeight: FontWeight.bold,
                            fontSize: 15))),
                Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                        color: Colors.red.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(12)),
                    child: Text('${tumRaporlar.length}',
                        style: const TextStyle(
                            color: Colors.redAccent,
                            fontWeight: FontWeight.bold,
                            fontSize: 12))),
              ]),
            ),
            Expanded(
                child: ListView.builder(
              padding: const EdgeInsets.only(top: 4),
              itemCount: tumRaporlar.length,
              itemBuilder: (context, index) {
                final r = tumRaporlar[index];
                final afetAdi = r.tur.split(' - ').first;
                return InkWell(
                  onTap: () => _detayGoster(r),
                  child: Container(
                    margin:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: r.isSOS
                          ? Colors.red.withOpacity(0.1)
                          : Colors.white.withOpacity(0.04),
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: r.renk.withOpacity(0.2)),
                    ),
                    child: Row(children: [
                      Container(
                          padding: const EdgeInsets.all(6),
                          decoration: BoxDecoration(
                              color: r.renk.withOpacity(0.2),
                              shape: BoxShape.circle),
                          child: Icon(afetIkonu(afetAdi),
                              color: r.renk, size: 18)),
                      const SizedBox(width: 10),
                      Expanded(
                          child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                            Text(r.tur,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 12)),
                            const SizedBox(height: 2),
                            Text(r.aciklama,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(
                                    color: Colors.white54, fontSize: 10)),
                            const SizedBox(height: 3),
                            Row(children: [
                              Icon(r.onayli ? Icons.verified : Icons.pending,
                                  size: 10,
                                  color: r.onayli
                                      ? Colors.greenAccent
                                      : Colors.amber),
                              const SizedBox(width: 3),
                              Text(r.onayli ? 'Doğrulandı' : 'Bekliyor',
                                  style: TextStyle(
                                      fontSize: 9,
                                      color: r.onayli
                                          ? Colors.greenAccent
                                          : Colors.amber)),
                            ]),
                          ])),
                    ]),
                  ),
                );
              },
            )),
          ]),
        ),
      ),
    ]);
  }

  Widget _haritaOlustur() {
    _tumVerileriOlustur();
    return FlutterMap(
      options: MapOptions(initialCenter: kullaniciKonumu, initialZoom: 6.0),
      children: [
        TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
            userAgentPackageName: 'com.hackathon.umutagi'),
        MarkerLayer(
          markers: [
            ...tumRaporlar.map((r) => Marker(
                  point: r.konum,
                  width: 80,
                  height: 80,
                  child: GestureDetector(
                      onTap: () => _detayGoster(r),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Container(
                            padding: const EdgeInsets.all(5),
                            decoration: BoxDecoration(
                                color: r.renk.withOpacity(0.85),
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                      color: r.renk.withOpacity(0.6),
                                      blurRadius: 10,
                                      spreadRadius: 3)
                                ]),
                            child: Icon(
                                r.isSOS
                                    ? Icons.warning_amber
                                    : afetIkonu(r.tur.split(' - ').first),
                                color: Colors.white,
                                size: 18)),
                        const SizedBox(height: 1),
                        Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 3, vertical: 1),
                            decoration: BoxDecoration(
                                color: Colors.black87,
                                borderRadius: BorderRadius.circular(3)),
                            child: Text(
                                r.tur.length > 20
                                    ? r.tur.split(' - ').last
                                    : r.tur,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontSize: 7,
                                    fontWeight: FontWeight.bold))),
                      ])),
                )),
            // Yardım Ekipleri
            ...yardimEkipleri.map((ekip) => Marker(
                  point: ekip.konum,
                  width: 120,
                  height: 80,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                            color: ekip.renk.withOpacity(0.9),
                            shape: BoxShape.circle,
                            boxShadow: [
                              BoxShadow(
                                  color: ekip.renk.withOpacity(0.5),
                                  blurRadius: 8,
                                  spreadRadius: 2)
                            ]),
                        child: Icon(ekip.ikon, color: Colors.white, size: 22)),
                    const SizedBox(height: 2),
                    Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 2),
                        decoration: BoxDecoration(
                            color: Colors.black87,
                            borderRadius: BorderRadius.circular(4)),
                        child: Text(ekip.isim,
                            style: const TextStyle(
                                color: Colors.white,
                                fontSize: 8,
                                fontWeight: FontWeight.bold))),
                  ]),
                )),
            // Yardım Tırları (SADECE yetkili haritasında)
            ...yardimTirlari.map((tir) => Marker(
                  point: tir.konum,
                  width: 130,
                  height: 80,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                        padding: const EdgeInsets.all(5),
                        decoration: BoxDecoration(
                            color: Colors.amber.shade800,
                            borderRadius: BorderRadius.circular(6),
                            boxShadow: [
                              BoxShadow(
                                  color: Colors.amber.withOpacity(0.4),
                                  blurRadius: 6,
                                  spreadRadius: 1)
                            ]),
                        child: const Icon(Icons.local_shipping,
                            color: Colors.white, size: 22)),
                    const SizedBox(height: 2),
                    Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 2),
                        decoration: BoxDecoration(
                            color: Colors.black87,
                            borderRadius: BorderRadius.circular(4)),
                        child: Text('${tir.plaka}\n${tir.yukTuru}',
                            textAlign: TextAlign.center,
                            style: const TextStyle(
                                color: Colors.amberAccent,
                                fontSize: 7,
                                fontWeight: FontWeight.bold))),
                  ]),
                )),
          ],
        ),
      ],
    );
  }

  Widget _listeOlustur() {
    return ListView.builder(
      padding: const EdgeInsets.only(top: 8),
      itemCount: tumRaporlar.length,
      itemBuilder: (context, index) {
        final r = tumRaporlar[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
          color: const Color(0xFF1A1A1A),
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(
                  color: r.onayli
                      ? Colors.green.withOpacity(0.3)
                      : Colors.transparent)),
          child: ListTile(
            leading: r.isSOS
                ? const Icon(Icons.warning_rounded,
                    color: Colors.redAccent, size: 36)
                : CircleAvatar(
                    backgroundColor: r.renk.withOpacity(0.2),
                    child: Text(r.oncelik.toString(),
                        style: TextStyle(
                            color: r.renk, fontWeight: FontWeight.bold))),
            title: Text(r.tur,
                style: TextStyle(
                    color: r.isSOS ? Colors.redAccent : Colors.white,
                    fontWeight: FontWeight.bold)),
            subtitle: Text(
                r.onayli ? "YAYINDA" : "ONAY BEKLİYOR\n${r.aciklama}",
                style: const TextStyle(color: Colors.white70, fontSize: 13)),
            trailing: r.onayli
                ? const Icon(Icons.check_circle, color: Colors.green)
                : ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue.shade800),
                    onPressed: () {
                      r.onayli = true;
                      widget.onGuncelle();
                    },
                    child: const Text("Doğrula",
                        style: TextStyle(color: Colors.white))),
          ),
        );
      },
    );
  }

  void _detayGoster(Rapor r) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: const Color(0xFF1E1E1E),
        title: Row(children: [
          Icon(
              r.isSOS
                  ? Icons.warning_amber
                  : afetIkonu(r.tur.split(' - ').first),
              color: r.renk,
              size: 28),
          const SizedBox(width: 10),
          Expanded(
              child: Text(r.tur,
                  style: TextStyle(
                      color: r.isSOS ? Colors.redAccent : Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 16))),
        ]),
        content: SizedBox(
          width: 350,
          height: 320,
          child:
              Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(r.aciklama,
                style: const TextStyle(color: Colors.white70, height: 1.5)),
            const SizedBox(height: 8),
            Row(children: [
              Icon(r.onayli ? Icons.verified : Icons.pending,
                  size: 16,
                  color: r.onayli ? Colors.greenAccent : Colors.amber),
              const SizedBox(width: 6),
              Text(r.onayli ? 'Doğrulandı' : 'Onay Bekliyor',
                  style: TextStyle(
                      color: r.onayli ? Colors.greenAccent : Colors.amber,
                      fontSize: 13)),
            ]),
            const SizedBox(height: 8),
            Text(
                'Konum: ${r.konum.latitude.toStringAsFixed(4)}, ${r.konum.longitude.toStringAsFixed(4)}',
                style: const TextStyle(color: Colors.white38, fontSize: 11)),
            const SizedBox(height: 10),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: FlutterMap(
                  options:
                      MapOptions(initialCenter: r.konum, initialZoom: 13.0),
                  children: [
                    TileLayer(
                        urlTemplate:
                            'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
                        userAgentPackageName: 'com.hackathon.umutagi'),
                    MarkerLayer(markers: [
                      Marker(
                          point: r.konum,
                          width: 60,
                          height: 60,
                          child: Icon(
                              r.isSOS
                                  ? Icons.warning_amber
                                  : afetIkonu(r.tur.split(' - ').first),
                              color: r.renk,
                              size: 40)),
                    ]),
                  ],
                ),
              ),
            ),
          ]),
        ),
        actions: [
          if (!r.onayli)
            TextButton(
                onPressed: () {
                  setState(() => r.onayli = true);
                  widget.onGuncelle();
                  Navigator.pop(ctx);
                },
                child: const Text('DOĞRULA',
                    style: TextStyle(color: Colors.blueAccent))),
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child:
                  const Text('KAPAT', style: TextStyle(color: Colors.white54))),
        ],
      ),
    );
  }
}

class LoginEkrani extends StatelessWidget {
  final VoidCallback onLoginSuccess;
  LoginEkrani({super.key, required this.onLoginSuccess});
  final _u = TextEditingController();
  final _p = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.admin_panel_settings_rounded,
              size: 80, color: Colors.redAccent),
          const SizedBox(height: 24),
          const Text("YETKİLİ GİRİŞİ",
              style: TextStyle(
                  fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const SizedBox(height: 32),
          TextField(
              controller: _u,
              decoration: InputDecoration(
                  labelText: 'Kullanıcı Adı',
                  hintText: 'Bülent',
                  filled: true,
                  fillColor: const Color(0xFF1E1E1E),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none))),
          const SizedBox(height: 16),
          TextField(
              controller: _p,
              obscureText: true,
              decoration: InputDecoration(
                  labelText: 'Şifre',
                  hintText: '123',
                  filled: true,
                  fillColor: const Color(0xFF1E1E1E),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none))),
          const SizedBox(height: 32),
          SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red.shade800,
                      padding: const EdgeInsets.symmetric(vertical: 16)),
                  onPressed: () {
                    if (_u.text == "Bülent" && _p.text == "123") {
                      onLoginSuccess();
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
                          content: Text("Hatalı Giriş!"),
                          backgroundColor: Colors.red));
                    }
                  },
                  child: const Text("GİRİŞ YAP",
                      style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16))))
        ],
      ),
    );
  }
}

// --- FORMLAR EKRANLARI ---
class BildirEkrani extends StatefulWidget {
  final VoidCallback onGonder;
  const BildirEkrani({super.key, required this.onGonder});
  @override
  State<BildirEkrani> createState() => _BildirEkraniState();
}

class _BildirEkraniState extends State<BildirEkrani> {
  String secilenAfet = 'Enkaz / Çökme';
  final aciklamaCtrl = TextEditingController();
  final turler = ['Enkaz / Çökme', 'Yangın', 'Sel', 'Tıbbi Acil Durum'];

  void _gonder(Color c, int p) {
    final raporKonum = LatLng(
        kullaniciKonumu.latitude + (Random().nextDouble() - 0.5) * 0.02,
        kullaniciKonumu.longitude + (Random().nextDouble() - 0.5) * 0.02);
    tumRaporlar.add(Rapor(
        tur: secilenAfet,
        aciklama: aciklamaCtrl.text,
        oncelik: p,
        renk: c,
        konum: raporKonum));
    _tirlariOlustur(raporKonum);
    widget.onGonder();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text("Afet Durumu Bildir"),
          backgroundColor: const Color(0xFF121212),
          elevation: 0),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            DropdownButtonFormField<String>(
              initialValue: secilenAfet,
              dropdownColor: const Color(0xFF1E1E1E),
              decoration: InputDecoration(
                  labelText: "Afet Türü",
                  filled: true,
                  fillColor: const Color(0xFF1E1E1E),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none)),
              items: turler
                  .map((t) => DropdownMenuItem(
                      value: t,
                      child:
                          Text(t, style: const TextStyle(color: Colors.white))))
                  .toList(),
              onChanged: (v) => setState(() => secilenAfet = v!),
            ),
            const SizedBox(height: 20),
            TextField(
                controller: aciklamaCtrl,
                maxLines: 4,
                decoration: InputDecoration(
                    hintText: "Durumu açıklayın...",
                    filled: true,
                    fillColor: const Color(0xFF1E1E1E),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none))),
            const SizedBox(height: 30),
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red.shade700,
                    padding: const EdgeInsets.all(16)),
                onPressed: () => _gonder(Colors.red, 10),
                child: const Text("KIRMIZI KOD (Çok Acil)",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16))),
            const SizedBox(height: 12),
            ElevatedButton(
                style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange.shade700,
                    padding: const EdgeInsets.all(16)),
                onPressed: () => _gonder(Colors.orange, 5),
                child: const Text("SARI KOD (Orta)",
                    style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 16))),
          ],
        ),
      ),
    );
  }
}

class IhtiyacEkrani extends StatefulWidget {
  final VoidCallback onGonder;
  const IhtiyacEkrani({super.key, required this.onGonder});
  @override
  State<IhtiyacEkrani> createState() => _IhtiyacEkraniState();
}

class _IhtiyacEkraniState extends State<IhtiyacEkrani> {
  final detayCtrl = TextEditingController();
  void _ekle() {
    tumIhtiyaclar.add(Ihtiyac(
        tur: "Genel İhtiyaç",
        aciklama: detayCtrl.text,
        tahminiVaris: "Sevkiyat: Yaklaşık 30 dk"));
    widget.onGonder();
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text("İhtiyaç Talebi"),
          backgroundColor: const Color(0xFF121212),
          elevation: 0),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          children: [
            TextField(
                controller: detayCtrl,
                decoration: InputDecoration(
                    labelText: "Neye ihtiyacınız var?",
                    filled: true,
                    fillColor: const Color(0xFF1E1E1E),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: BorderSide.none))),
            const SizedBox(height: 20),
            SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue.shade700,
                        padding: const EdgeInsets.all(16)),
                    onPressed: _ekle,
                    child: const Text("TALEBİ GÖNDER",
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold)))),
            const SizedBox(height: 30),
            Expanded(
              child: ListView.builder(
                itemCount: tumIhtiyaclar.length,
                itemBuilder: (c, i) => Card(
                    color: const Color(0xFF1A1A1A),
                    child: ListTile(
                        title: Text(tumIhtiyaclar[i].aciklama),
                        subtitle: Text(tumIhtiyaclar[i].tahminiVaris,
                            style:
                                const TextStyle(color: Colors.greenAccent)))),
              ),
            )
          ],
        ),
      ),
    );
  }
}

class KayipEkrani extends StatefulWidget {
  final VoidCallback onGonder;
  const KayipEkrani({super.key, required this.onGonder});
  @override
  State<KayipEkrani> createState() => _KayipEkraniState();
}

class _KayipEkraniState extends State<KayipEkrani> {
  final adSoyadCtrl = TextEditingController();
  final tcCtrl = TextEditingController();
  final yasCtrl = TextEditingController();
  File? selectedImage;
  Uint8List? selectedImageBytes;
  final ImagePicker _picker = ImagePicker();

  Future<void> _fotoSecimi() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      final bytes = await image.readAsBytes();
      setState(() {
        selectedImage = File(image.path);
        selectedImageBytes = bytes;
      });
    }
  }

  void _ekle() {
    if (adSoyadCtrl.text.trim().isEmpty ||
        yasCtrl.text.trim().isEmpty ||
        tcCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text("Ad Soyad, Yaş ve T.C. No giriniz"),
          backgroundColor: Colors.orange));
      return;
    }

    tumKayiplar.add(Kayip(
      adSoyad: adSoyadCtrl.text.trim(),
      tcNo: tcCtrl.text.trim(),
      yas: yasCtrl.text.trim(),
      foto: selectedImageBytes,
    ));
    widget.onGonder();
    adSoyadCtrl.clear();
    tcCtrl.clear();
    yasCtrl.clear();
    setState(() {
      selectedImage = null;
      selectedImageBytes = null;
    });
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text("Kayıp İlanları ve Analiz"),
          backgroundColor: const Color(0xFF121212),
          elevation: 0),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            // --- MANUEL KAYIP İLANI ---
            Card(
              color: const Color(0xFF1A1A1A),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("Kayıp Kişi İlanı",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold)),
                    const SizedBox(height: 12),
                    TextField(
                        controller: adSoyadCtrl,
                        decoration: InputDecoration(
                            labelText: "Ad Soyad",
                            filled: true,
                            fillColor: const Color(0xFF2E2E2E),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide.none))),
                    const SizedBox(height: 12),
                    TextField(
                        controller: yasCtrl,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                            labelText: "Yaş",
                            filled: true,
                            fillColor: const Color(0xFF2E2E2E),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide.none))),
                    const SizedBox(height: 12),
                    TextField(
                        controller: tcCtrl,
                        keyboardType: TextInputType.number,
                        decoration: InputDecoration(
                            labelText: "T.C. Kimlik No",
                            helperText: "Bu değer halka açık olmayacak",
                            helperStyle: const TextStyle(
                                color: Colors.white54, fontSize: 12),
                            filled: true,
                            fillColor: const Color(0xFF2E2E2E),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(8),
                                borderSide: BorderSide.none))),
                    const SizedBox(height: 12),
                    if (selectedImageBytes != null)
                      ClipRRect(
                        borderRadius: BorderRadius.circular(8),
                        child: Image.memory(selectedImageBytes!,
                            height: 180,
                            width: double.infinity,
                            fit: BoxFit.cover),
                      ),
                    if (selectedImageBytes != null) const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        icon: const Icon(Icons.photo_camera),
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue.shade700,
                            padding: const EdgeInsets.all(12)),
                        onPressed: _fotoSecimi,
                        label: const Text("Fotoğraf Ekle",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.orange.shade700,
                            padding: const EdgeInsets.all(12)),
                        onPressed: _ekle,
                        child: const Text("İLANI KAYDET",
                            style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),

            const SizedBox(height: 20),

            // --- İLAN LİSTESİ ---
            if (tumKayiplar.isNotEmpty)
              Card(
                color: const Color(0xFF1A1A1A),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text("Kayıtlı İlanlar",
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.bold)),
                      const SizedBox(height: 12),
                      ...tumKayiplar.map((kayip) => ListTile(
                            contentPadding: const EdgeInsets.symmetric(
                                vertical: 8, horizontal: 0),
                            leading: kayip.foto != null
                                ? CircleAvatar(
                                    radius: 28,
                                    backgroundImage: MemoryImage(kayip.foto!))
                                : const CircleAvatar(
                                    radius: 28,
                                    backgroundColor: Colors.orangeAccent,
                                    child: Icon(Icons.person_search,
                                        color: Colors.black)),
                            title: Text(kayip.adSoyad,
                                style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.bold)),
                            subtitle: Text("Yaş: ${kayip.yas}",
                                style: const TextStyle(color: Colors.white70)),
                            dense: true,
                          )),
                    ],
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    adSoyadCtrl.dispose();
    tcCtrl.dispose();
    yasCtrl.dispose();
    super.dispose();
  }
}
