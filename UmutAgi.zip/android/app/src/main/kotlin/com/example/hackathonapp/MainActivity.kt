package com.example.hackathonapp

import android.app.SearchManager
import android.content.Intent
import android.os.Bundle
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "com.umutagi.voice/intent"
    private var initialQuery: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
        // If engine is already running, send the intent immediately
        flutterEngine?.dartExecutor?.binaryMessenger?.let {
            initialQuery?.let { query ->
                MethodChannel(it, CHANNEL).invokeMethod("onVoiceCommand", query)
                initialQuery = null
            }
        }
    }

    private fun handleIntent(intent: Intent) {
        if (Intent.ACTION_SEARCH == intent.action || "com.google.android.gms.actions.SEARCH_ACTION" == intent.action) {
            val query = intent.getStringExtra(SearchManager.QUERY)
            if (query != null) {
                initialQuery = query
            }
        }
    }

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "getInitialQuery") {
                result.success(initialQuery)
                initialQuery = null
            } else {
                result.notImplemented()
            }
        }
    }
}
